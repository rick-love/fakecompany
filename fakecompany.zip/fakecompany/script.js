

setTimeout(function(){
	document.getElementById('modal').style.display = 'block' }, 3000);

closeModal.addEventListener("click", function(){
	document.getElementById('modal').style.display = 'none';
});

